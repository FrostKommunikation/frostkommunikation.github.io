// JavaScript
window.sr = ScrollReveal();
sr.reveal('.services__wrap > div', { duration: 600, delay: 50 });
sr.reveal('.cases__item', { duration: 600, delay: 50 });
sr.reveal('.footer', { duration: 600, delay: 50 });
